//
//  remote_model_accessTests.swift
//  remote model accessTests
//
//  Created by Thomas Grossman on 4/13/25.
//

import Testing
@testable import remote_model_access

struct remote_model_accessTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
