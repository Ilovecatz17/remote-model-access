//
//  remote_model_accessApp.swift
//  remote model access
//
//  Created by Thomas Grossman on 4/13/25.
//

import SwiftUI

@main
struct remote_model_accessApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
